<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('zh_order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('zh_order_id')->constrained('zh_orders')->onDelete('cascade');
            $table->string('name');
            $table->integer('quantity');
            $table->integer('price');
            $table->string('image')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('zh_order_items');
    }
};
